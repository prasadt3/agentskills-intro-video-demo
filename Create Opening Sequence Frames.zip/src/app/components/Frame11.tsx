import { motion } from 'motion/react';

export function Frame11() {
  const tools = ['Claude', 'ChatGPT', 'Cursor', 'Agentman'];
  const skillTypes = [
    { label: 'Procedures', position: { x: -280, y: -160 } },
    { label: 'Decision Logic', position: { x: 280, y: -160 } },
    { label: 'Business Rules', position: { x: -280, y: 160 } },
    { label: 'Templates', position: { x: 280, y: 160 } },
  ];

  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      {/* Headline */}
      <motion.div
        className="text-[56px] tracking-[-0.02em]"
        style={{ fontWeight: 700, marginBottom: '180px' }}
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
      >
        <span style={{ color: '#FAF9F5' }}>Works </span>
        <span style={{ color: '#D97757' }}>everywhere.</span>
      </motion.div>

      {/* Main diagram container */}
      <div className="relative flex items-center justify-center" style={{ width: '1200px', height: '500px' }}>
        {/* Center box */}
        <motion.div
          className="absolute rounded-xl border-2 flex flex-col"
          style={{
            width: '620px',
            height: '160px',
            borderColor: 'rgba(250, 249, 245, 0.4)',
            backgroundColor: '#1a1a19',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            padding: '16px',
            gap: '12px',
          }}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.3, ease: 'easeOut' }}
        >
          {/* Header bar */}
          <div
            className="rounded-lg flex items-center justify-center"
            style={{
              backgroundColor: '#D97757',
              height: '50px',
            }}
          >
            <span className="text-[22px]" style={{ color: '#FAF9F5', fontWeight: 600 }}>
              Your AI Tools
            </span>
          </div>

          {/* Four sub-boxes */}
          <div className="flex gap-3" style={{ height: '58px' }}>
            {tools.map((tool, idx) => (
              <div
                key={idx}
                className="flex-1 rounded-lg border flex items-center justify-center"
                style={{
                  backgroundColor: '#1a1a19',
                  borderColor: 'rgba(250, 249, 245, 0.25)',
                }}
              >
                <span className="text-[16px]" style={{ color: '#FAF9F5', fontWeight: 500 }}>
                  {tool}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Outer nodes - Skill types */}
        {skillTypes.map((skill, idx) => (
          <motion.div
            key={idx}
            className="absolute rounded-lg border flex items-center justify-center"
            style={{
              width: '170px',
              height: '75px',
              borderColor: 'rgba(250, 249, 245, 0.4)',
              backgroundColor: 'transparent',
              left: `calc(50% + ${skill.position.x}px)`,
              top: `calc(50% + ${skill.position.y}px)`,
              transform: 'translate(-50%, -50%)',
            }}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0.5 + idx * 0.1, ease: 'easeOut' }}
          >
            <span className="text-[18px] text-center" style={{ color: '#FAF9F5', fontWeight: 500 }}>
              {skill.label}
            </span>
          </motion.div>
        ))}

        {/* Connection lines with arrows */}
        {skillTypes.map((skill, idx) => {
          // Calculate line positions and angles
          const startX = skill.position.x;
          const startY = skill.position.y;
          const endX = skill.position.x > 0 ? 310 : -310; // Edge of center box
          const endY = skill.position.y > 0 ? 80 : -80;
          
          const length = Math.sqrt(Math.pow(startX - endX, 2) + Math.pow(startY - endY, 2));
          const angle = Math.atan2(endY - startY, endX - startX) * (180 / Math.PI);

          return (
            <g key={`connection-${idx}`}>
              {/* Dashed line */}
              <motion.div
                className="absolute"
                style={{
                  width: `${length}px`,
                  height: '2px',
                  left: `calc(50% + ${startX}px)`,
                  top: `calc(50% + ${startY}px)`,
                  transformOrigin: 'left center',
                  transform: `rotate(${angle}deg)`,
                  background: `repeating-linear-gradient(
                    to right,
                    rgba(250, 249, 245, 0.35) 0px,
                    rgba(250, 249, 245, 0.35) 5px,
                    transparent 5px,
                    transparent 9px
                  )`,
                }}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 0.4, delay: 0.9 + idx * 0.05, ease: 'easeOut' }}
              />
              
              {/* Arrow head */}
              <motion.div
                className="absolute"
                style={{
                  width: 0,
                  height: 0,
                  borderLeft: '6px solid rgba(250, 249, 245, 0.35)',
                  borderTop: '5px solid transparent',
                  borderBottom: '5px solid transparent',
                  left: `calc(50% + ${endX}px)`,
                  top: `calc(50% + ${endY}px)`,
                  transform: `translate(-6px, -5px) rotate(${angle}deg)`,
                  transformOrigin: 'left center',
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.2, delay: 1.3, ease: 'easeOut' }}
              />
            </g>
          );
        })}
      </div>
    </div>
  );
}